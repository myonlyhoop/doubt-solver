import React from 'react'

export default function Home() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-white bg-grid-gray-100">
      <div className="bg-white bg-opacity-90 p-8 rounded-lg shadow-md text-center">
        <h1 className="text-4xl mb-6">
          Doubt<span className="font-bold">Solver.</span>
        </h1>
        <button className="bg-black text-white px-6 py-2 rounded hover:bg-gray-800 transition-colors">
          Sign in with Google
        </button>
      </div>
    </main>
  )
}